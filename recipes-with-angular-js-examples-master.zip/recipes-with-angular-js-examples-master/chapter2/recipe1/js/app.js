function MyCtrl($scope) {
  $scope.value = "some value";
}