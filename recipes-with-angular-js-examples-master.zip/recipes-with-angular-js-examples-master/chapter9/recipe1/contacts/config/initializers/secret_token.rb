# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Contacts::Application.config.secret_token = '830798170fe06fbf75c3bdc4726f712bd5aeec8f460199afbabb88fd0a77a2077c0e8e5112d845d80d216e5c9d7a53e0cdb1ef5ea120008dc6c7d993f5c1389d'
